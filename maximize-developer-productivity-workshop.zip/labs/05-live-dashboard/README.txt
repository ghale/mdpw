Lab 05: Live dashboard
======================

NOTE: To view the live dashboard, use the credentials provided in the slides

- Open `index.html` in Chrome or Firefox

- Run some builds and watch them appear on the chart in real-time
